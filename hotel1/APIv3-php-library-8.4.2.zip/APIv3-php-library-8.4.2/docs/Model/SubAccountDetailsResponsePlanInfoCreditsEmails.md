# SubAccountDetailsResponsePlanInfoCreditsEmails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quantity** | **int** | Quantity of email messaging limits provided | [optional] 
**remaining** | **int** | Available email messaging limits for use | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


