# ScheduleSmtpEmail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**messageId** | **string** | Message ID of the transactional email scheduled | [optional] 
**messageIds** | **string[]** |  | [optional] 
**batchId** | **string** | Batch ID of the batch transactional email scheduled | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


