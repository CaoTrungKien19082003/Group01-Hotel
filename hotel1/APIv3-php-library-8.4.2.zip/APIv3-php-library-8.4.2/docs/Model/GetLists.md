# GetLists

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lists** | **object[]** | Listing of all the lists available in your account | [optional] 
**count** | **int** | Number of lists in your account | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


