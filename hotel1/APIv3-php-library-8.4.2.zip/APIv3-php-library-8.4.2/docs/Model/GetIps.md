# GetIps

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ips** | [**\SendinBlue\Client\Model\GetIp[]**](GetIp.md) | Dedicated IP(s) available on your account | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


