# MasterDetailsResponseBillingInfoAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**streetAddress** | **string** | Street address | [optional] 
**locality** | **string** | Locality | [optional] 
**postalCode** | **string** | Postal code | [optional] 
**stateCode** | **string** | State code | [optional] 
**countryCode** | **string** | Country code | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


