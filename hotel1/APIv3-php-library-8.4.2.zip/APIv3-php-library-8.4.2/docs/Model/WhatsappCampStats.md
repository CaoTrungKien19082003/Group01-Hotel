# WhatsappCampStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sent** | **int** |  | 
**delivered** | **int** |  | 
**read** | **int** |  | 
**unsubscribe** | **int** |  | 
**notSent** | **int** |  | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


