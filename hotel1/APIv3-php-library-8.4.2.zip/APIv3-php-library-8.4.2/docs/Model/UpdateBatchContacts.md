# UpdateBatchContacts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**contacts** | [**\SendinBlue\Client\Model\UpdateBatchContactsContacts[]**](UpdateBatchContactsContacts.md) | List of contacts to be updated | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


