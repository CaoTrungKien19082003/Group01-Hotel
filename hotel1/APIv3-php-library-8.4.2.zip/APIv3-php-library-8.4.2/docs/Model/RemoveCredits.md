# RemoveCredits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sms** | **int** | Required if email credits are empty. SMS credits to be removed from the child account | [optional] 
**email** | **int** | Required if sms credits are empty. Email credits to be removed from the child account | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


