# UpdateChild

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **string** | New Email address to update the child account | [optional] 
**firstName** | **string** | New First name to use to update the child account | [optional] 
**lastName** | **string** | New Last name to use to update the child account | [optional] 
**companyName** | **string** | New Company name to use to update the child account | [optional] 
**password** | **string** | New password for the child account to login | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


